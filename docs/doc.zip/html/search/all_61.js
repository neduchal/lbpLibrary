var searchData=
[
  ['adaptorpointer',['AdaptorPointer',['../const_8h.html#af441a30859bf31b79d3c8424fb6b77b5',1,'const.h']]],
  ['adaptortype',['AdaptorType',['../const_8h.html#a5fe6091b5afd6f78054067a66c0378ff',1,'const.h']]]
];
