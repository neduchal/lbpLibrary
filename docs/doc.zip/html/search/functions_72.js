var searchData=
[
  ['realtimelbp',['RealTimeLbp',['../realtimeLbp_8h.html#a03462d3e21eb0dc2121b24feecd1c8b8',1,'RealTimeLbp(int rows, int columns, const int *data, int *result):&#160;realtimeLbp.h'],['../lbp_8h.html#a30e644ac23930d2acfb3a7a239bc9435',1,'realTimeLbp(int rows, int columns, const int *data, int *result):&#160;lbp.c']]],
  ['realtimelbpcxx',['realTimeLbpCxx',['../lbpCxx_8h.html#a740037502d23187ab516022998f6706a',1,'lbpCxx.cxx']]],
  ['rescaleimageintensity',['rescaleImageIntensity',['../io_8h.html#ab7fa44bb64bfb0fe2f0ccf1889d87e94',1,'io.h']]],
  ['rotmin',['rotmin',['../mapping_8h.html#a86e967cdd5b15499ac3257a93223001d',1,'mapping.h']]]
];
