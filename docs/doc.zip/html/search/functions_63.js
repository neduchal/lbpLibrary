var searchData=
[
  ['convolutionfft',['convolutionFFT',['../convolution_8h.html#ad55efb68a9883d0610f85eaac876d8df',1,'convolution.h']]],
  ['createsimplehistogram',['createSimpleHistogram',['../histogram_8h.html#a2e4dd04882fe86b0b9e18a9e94c2cd64',1,'histogram.h']]]
];
