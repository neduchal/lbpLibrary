var searchData=
[
  ['max_5fradius',['MAX_RADIUS',['../imageToLbpFilter_8h.html#a7b18b821e397ef6bf1502bc41462d630',1,'imageToLbpFilter.h']]],
  ['max_5fsamples',['MAX_SAMPLES',['../imageToLbpFilter_8h.html#a78f316da3a87bf72cb1647786b64bf0e',1,'imageToLbpFilter.h']]]
];
